Mindspace - A Minimalist Frontend Website

🌟 About the Project
Mindspace is a sleek, minimalist website built using HTML and CSS. It is designed to provide a calming user experience with a clean UI and smooth navigation.

🚀 Features
Fully responsive design
Clean and modern UI
Easy-to-read typography
Lightweight & fast performance
🛠️ Technologies Used
HTML5
CSS3 (Flexbox, Grid, Animations)

📌 Installation & Usage
Clone the Repository:
git clone https://github.com/AKHILESH2208/MINDSPACE.git
